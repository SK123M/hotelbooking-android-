import 'package:flutter/material.dart';
import 'package:hotel_clg/admin/admin_dashboard.dart';
import 'package:hotel_clg/common.dart';
import 'package:hotel_clg/register_screen.dart';
import 'package:hotel_clg/user/user_home.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController userTextEditingController =
      TextEditingController();
  final TextEditingController passwordTextEditingController =
      TextEditingController();

  @override
  void initState() {
    super.initState();
    initializeSharedPreferences();
  }

  Future<void> initializeSharedPreferences() async {
    sharedPreferences = await SharedPreferences.getInstance();
    setState(() {}); // Trigger rebuild after initialization
  }

  @override
  Widget build(BuildContext context) {
    if (sharedPreferences == null) {
      return Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }
    return Scaffold(
      body: Container(
        padding: EdgeInsets.symmetric(vertical: 20, horizontal: 20),
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage(
                  "assets/images/h1.jpg",
                ),
                fit: BoxFit.cover,
                opacity: 0.8)),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.electric_bolt_outlined,
                  color: Colors.white,
                  size: 45,
                ),
                SizedBox(
                  width: 30,
                ),
                Text(
                  "Login",
                  style: CommonStyles.whiteText28BoldW500(),
                )
              ],
            ),
            Column(
              children: [
                Container(
                   decoration: BoxDecoration(
                     borderRadius: BorderRadius.circular(13),
                     color: Colors.white,

                   ),
                  child: TextFormField(

                    controller: userTextEditingController,
                    style: CommonStyles.black15(),
                    decoration: InputDecoration(
                      fillColor: Colors.white,
                      hintText: "E - Mail ID",
                      labelText: "E - Mail ID",
                      labelStyle: CommonStyles.black15(),
                      hintStyle: CommonStyles.black15(),
                      border: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.white),
                          borderRadius: BorderRadius.circular(13)),
                    ),
                  ),
                ),
                SizedBox(
                  height: 30,
                ),
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(13),
                    color: Colors.white,

                  ),
                  child: TextFormField(
                    style: CommonStyles.black15(),
                    controller: passwordTextEditingController,
                    obscureText: true,
                    decoration: InputDecoration(
                      fillColor: Colors.white,
                      hintText: "Password",
                      labelText: "Password",
                      labelStyle: CommonStyles.black15(),
                      hintStyle: CommonStyles.black15(),
                      border: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.white),
                          borderRadius: BorderRadius.circular(13)),
                    ),
                  ),
                ),
              ],
            ),
            Column(
              children: [
                ElevatedButton(
                    onPressed: () {
                      login();
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 10, horizontal: 70),
                      child: Text("Log In",
                          style: CommonStyles.whiteText18BoldW500()),
                    ),
                    style: ButtonStyle(
                        backgroundColor:
                            MaterialStateProperty.all(Colors.green),
                        shape:
                            MaterialStateProperty.all<RoundedRectangleBorder>(
                                RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12.0),
                                    side: BorderSide(color: Colors.blue))))),
                SizedBox(
                  height: 10,
                ),
                Align(
                  alignment: Alignment.topRight,
                  child: TextButton(
                      onPressed: () {
                       Navigator.of(context).push(MaterialPageRoute(builder: (context)=> RegisterScreen()));
                      },
                      child: Text("Create New Account",
                          style: CommonStyles.whiteText18BoldW500())),
                )
              ],
            )
          ],
        ),
      ),
    );
  }

  SharedPreferences? sharedPreferences;

  void login() {
    if (sharedPreferences == null) {
      return;
    }

    final String? savedEmail = sharedPreferences!.getString('email');
    final String? savedPassword = sharedPreferences!.getString('password');


    if(userTextEditingController.text == 'admin@gmail.com' && passwordTextEditingController.text == 'admin'){
      Navigator.of(context).push(MaterialPageRoute(builder: (context) => AdminDashBoardScreen()));
    }
    else if (savedEmail == userTextEditingController.text && savedPassword == passwordTextEditingController.text) {
      Navigator.of(context).push(MaterialPageRoute(builder: (context) => UserHome()));
    } else {
      showAlertDialog(context, "Invalid credentials");
    }
  }


  void showAlertDialog(BuildContext context, String message) {
    Widget okButton = TextButton(
      child: Text(
        "OK",
        style: TextStyle(color: Colors.green, fontSize: 15),
      ),
      onPressed: () {
        Navigator.pop(context);
      },
    );

    AlertDialog alert = AlertDialog(
      title: Text(
        "Alert",
        style: TextStyle(color: Colors.black, fontSize: 15),
      ),
      content: Text(
        message,
        style: TextStyle(color: Colors.black, fontSize: 13),
      ),
      actions: [
        okButton,
      ],
    );

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }


 /* showAlertDialog(BuildContext context) {
    // set up the button
    Widget okButton = TextButton(
      child: Text(
        "OK",
        style: CommonStyles.green15(),
      ),
      onPressed: () {
        Navigator.pop(context);
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text(
        "Login Credentials !!!",
        style: CommonStyles.black15(),
      ),
      content: Text(
        "Check your User Name and Password !!!...",
        style: CommonStyles.black13(),
      ),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }*/
}
