import 'package:flutter/material.dart';
import 'package:hotel_clg/common.dart';
import 'package:hotel_clg/user/message_model.dart';


class ContactScreen extends StatefulWidget {
  const ContactScreen({super.key});

  @override
  State<ContactScreen> createState() => _ContactScreenState();
}

class _ContactScreenState extends State<ContactScreen> {

  final TextEditingController emailTextEditingController = TextEditingController();
  final TextEditingController nameTextEditingController = TextEditingController();
  final TextEditingController subTextEditingController = TextEditingController();
  final TextEditingController messageTextEditingController =
  TextEditingController();




  MessageModel _model = MessageModel();


  Future<void> _initData() async {
    await _model.createStudentData(); // Load data when initializing the state
    setState(() {}); // Trigger a rebuild to update the UI
  }
  @override
  void initState() {
    super.initState();
    _initData();
    setState(() {

    });
    // Load data when initializing the state
  }

  @override
  void dispose() {
    _model.saveData(); // Save data when the screen is disposed (e.g., navigating back)
    super.dispose();
  }





  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text(
            'Contact Us',
            style: CommonStyles.blue18900(),
          ),
          automaticallyImplyLeading: false,
          centerTitle: true,
        backgroundColor: Colors.blue,
         ),

      body: Container(

        padding: EdgeInsets.all(20),
        child: SingleChildScrollView(
          child: Column(

            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 20,
              ),
              Text(
                "Your Name",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              TextFormField(
controller: nameTextEditingController,
                style: CommonStyles.black13thin(),
                decoration: InputDecoration(
                  hintText: "Your Name",
                  labelStyle: CommonStyles.black13thin(),
                  hintStyle: CommonStyles.black13thin(),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(13)),
                ),
              ),


              SizedBox(
                height: 20,
              ),
              Text(
                "Your Email",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              TextFormField(
controller: emailTextEditingController,
                style: CommonStyles.black13thin(),
                decoration: InputDecoration(
                  hintText: "Your Email",
                  labelStyle: CommonStyles.black13thin(),
                  hintStyle: CommonStyles.black13thin(),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(13)),
                ),
              ),

              SizedBox(
                height: 20,
              ),
              Text(
                "Subject",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              TextFormField(

                controller: subTextEditingController,
                style: CommonStyles.black13thin(),
                decoration: InputDecoration(
                  hintText: "Subject",
                  labelStyle: CommonStyles.black13thin(),
                  hintStyle: CommonStyles.black13thin(),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(13)),
                ),
              ),

              SizedBox(
                height: 20,
              ),
              Text(
                "Your Message",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              TextFormField(
                controller: messageTextEditingController,
                maxLines: 6,
                style: CommonStyles.black13thin(),
                decoration: InputDecoration(
                  hintText: "Your Message",
                  labelStyle: CommonStyles.black13thin(),
                  hintStyle: CommonStyles.black13thin(),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(13)),
                ),
              ),

              SizedBox(height: 50,),
              Center(
                child: ElevatedButton(
                    onPressed: () async{

                        if (nameTextEditingController.text.isNotEmpty &&
                            subTextEditingController.text.isNotEmpty &&
                            emailTextEditingController.text.isNotEmpty &&
                            messageTextEditingController.text.isNotEmpty
                        ) {

                          _model.name.add(nameTextEditingController.text);
                          _model.emailid.add(subTextEditingController.text);
                          _model.sub.add(emailTextEditingController.text);
                          _model.message.add(messageTextEditingController.text);


                          await _model.saveData();

                          await _model.createStudentData();

                          nameTextEditingController.clear();
                          emailTextEditingController.clear();
                          subTextEditingController.clear();
                          messageTextEditingController.clear();

                          setState(() {
                            _model.createStudentData();
                            _model.saveData();
                          });
                          showAlertDialog(context);
                        } else {
                          showAlerErrortDialog(context);
                        }

                    },

                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 10, horizontal: 10),
                      child: Text("SEND MESSAGE",
                          style: CommonStyles
                              .whiteText15BoldW500()),
                    ),
                    style: ButtonStyle(
                        backgroundColor:
                        MaterialStateProperty.all(
                            Colors.green),
                        shape: MaterialStateProperty.all<
                            RoundedRectangleBorder>(
                            RoundedRectangleBorder(
                                borderRadius:
                                BorderRadius.circular(
                                    12.0),
                                side: BorderSide(
                                    color: Colors.blue))))),
              ),
            ],
          ),
        ),
      ),
    );
  }


  showAlerErrortDialog(BuildContext context) {
    // set up the button
    Widget okButton = TextButton(
      child: Text(
        "OK",
        style: CommonStyles.green15(),
      ),
      onPressed: () {
        Navigator.pop(context);
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text(
        "Contact Info Message !!!",
        style: CommonStyles.black15(),
      ),
      content: Text(
        "Check Entered Details !!!...",
        style: CommonStyles.black13(),
      ),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  showAlertDialog(BuildContext context) {
    // set up the button
    Widget okButton = TextButton(
      child: Text(
        "OK",
        style: CommonStyles.green15(),
      ),
      onPressed: () {
        Navigator.pop(context);
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text(
        "Contact Info Message !!!",
        style: CommonStyles.black15(),
      ),
      content: Text(
        "Your Message will be sent !!!...",
        style: CommonStyles.black13(),
      ),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }
}
