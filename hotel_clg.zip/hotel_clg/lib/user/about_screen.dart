import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:hotel_clg/admin/rate_model.dart';
import 'package:hotel_clg/common.dart';

class AboutScreen extends StatefulWidget {
  const AboutScreen({super.key});

  @override
  State<AboutScreen> createState() => _AboutScreenState();
}

class _AboutScreenState extends State<AboutScreen> {


  final TextEditingController croomTypeTextCntrl = TextEditingController();
  final TextEditingController clocationTextCntrl = TextEditingController();
  final TextEditingController camountTextCntrl = TextEditingController();
  final TextEditingController cdaysControler = TextEditingController();


  CreateRateModel _model = CreateRateModel();

  List<String> roomType = [
    'Single Bed Room',
    'Double Bed Room',
    'Deluxe Rooms',
    'Luxury Rooms',
  ];

  int selectRoom = 0;


  List<String> locationlist = [
    'Chennai',
    'Vellore',
    'ECR - Chennai',
    'Bangalore',
  ];
  double _rating = 0;
  int selectLoc = 0;


  Future<void> _initData() async {
    await _model.createRate(); // Load data when initializing the state
    setState(() {}); // Trigger a rebuild to update the UI
  }

  @override
  void initState() {
    super.initState();
    _initData();
    setState(() {});
    // Load data when initializing the state
  }

  @override
  void dispose() {
    _model
        .saveData(); // Save data when the screen is disposed (e.g., navigating back)
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Review Rating and About Us',
          style: CommonStyles.blue18900(),
        ),
        automaticallyImplyLeading: false,
        centerTitle: true,
        backgroundColor: Colors.blue,
      ),

      body: Container(
        padding: EdgeInsets.all(20),
        child: SingleChildScrollView(
          physics: BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [


              SizedBox(
                height: 20,
              ),
              Text(
                "Add Rating and FeedBack :-",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                "Choose Room Type",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              SizedBox(
                height: 80,
                child: ListView.builder(
                    itemCount: roomType.length,
                    shrinkWrap: true,
                    physics: BouncingScrollPhysics(),
                    scrollDirection: Axis.horizontal,
                    primary: false,
                    itemBuilder: (context, index) {
                      return Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: GestureDetector(
                          onTap: () {
                            setState(() {
                              selectRoom = index;
                              croomTypeTextCntrl.text = roomType[index];
                            });
                          },
                          child: Card(
                            shape: selectRoom == index
                                ? RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                                side:
                                BorderSide(width: 1, color: Colors.blue))
                                : null,
                            child: Padding(
                              padding: EdgeInsets.symmetric(
                                  vertical: 8, horizontal: 10),
                              child: Row(
                                children: [
                                  IconButton(
                                      onPressed: () {},
                                      icon: Icon(
                                        Icons.hotel,
                                        color: Colors.blue,
                                      )),
                                  SizedBox(
                                    width: 20,
                                  ),
                                  Text(
                                    roomType[index],
                                    style: selectRoom == index ? CommonStyles
                                        .blue13900() : CommonStyles.black13(),
                                  )
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    }),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                "Selected Room Type",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              TextFormField(
                readOnly: true,
                controller: croomTypeTextCntrl,
                style: CommonStyles.black13thin(),
                decoration: InputDecoration(
                  hintText: "Room Type",
                  labelStyle: CommonStyles.black13thin(),
                  hintStyle: CommonStyles.black13thin(),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(13)),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                "Choose Room Location",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              SizedBox(
                height: 80,
                child: ListView.builder(
                    itemCount: locationlist.length,
                    shrinkWrap: true,
                    scrollDirection: Axis.horizontal,
                    physics: BouncingScrollPhysics(),
                    primary: false,
                    itemBuilder: (context, index) {
                      return Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: GestureDetector(
                          onTap: () {
                            setState(() {
                              selectLoc = index;
                              clocationTextCntrl.text = locationlist[index];
                            });
                          },
                          child: Card(
                            shape: selectLoc == index
                                ? RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                                side:
                                BorderSide(width: 1, color: Colors.blue))
                                : null,
                            child: Padding(
                              padding: EdgeInsets.symmetric(
                                  vertical: 8, horizontal: 10),
                              child: Row(
                                children: [
                                  IconButton(
                                      onPressed: () {},
                                      icon: Icon(
                                        Icons.home_work_outlined,
                                        color: Colors.blue,
                                      )),
                                  SizedBox(
                                    width: 20,
                                  ),
                                  Text(
                                    locationlist[index],
                                    style: selectLoc == index ? CommonStyles
                                        .blue13900() : CommonStyles.black13(),
                                  )
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    }),
              ),


              SizedBox(
                height: 10,
              ),
              TextFormField(
                readOnly: true,
                controller: clocationTextCntrl,
                style: CommonStyles.black13thin(),
                decoration: InputDecoration(
                  hintText: "Location",
                  labelStyle: CommonStyles.black13thin(),
                  hintStyle: CommonStyles.black13thin(),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(13)),
                ),
              ),

              SizedBox(
                height: 20,
              ),
              Text(
                "Rating",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              RatingBar.builder(
                initialRating: _rating,
                minRating: 1,
                direction: Axis.horizontal,
                allowHalfRating: false,
                itemCount: 5,
                itemSize: 40,
                itemBuilder: (context, _) => Icon(
                  Icons.star_rate,
                  color: Colors.orange,
                ),
                onRatingUpdate: (rating) {
                  setState(() {
                    _rating = rating;
                    cdaysControler.text = _rating.toString();
                  });
                },
              ),

              SizedBox(
                height: 20,
              ),
              Text(
                "Feedback",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              TextFormField(
                controller: camountTextCntrl,
                style: CommonStyles.black13thin(),
                decoration: InputDecoration(
                  hintText: "Feedback",
                  labelStyle: CommonStyles.black13thin(),
                  hintStyle: CommonStyles.black13thin(),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(13)),
                ),
              ),
              SizedBox(
                height: 30,
              ),
              Center(
                child: ElevatedButton(
                    onPressed: () async {
                      if (croomTypeTextCntrl.text != null &&
                          croomTypeTextCntrl.text.isNotEmpty &&
                          camountTextCntrl.text != null &&
                          camountTextCntrl.text.isNotEmpty &&
                          cdaysControler.text != null &&
                          cdaysControler.text.isNotEmpty &&
                          clocationTextCntrl.text != null &&
                          clocationTextCntrl.text.isNotEmpty

                      ) {
                        _model.rroomType.add(croomTypeTextCntrl.text);
                        _model.rrate.add(camountTextCntrl.text);
                        _model.rdes.add(cdaysControler.text);
                        _model.rlocation.add(clocationTextCntrl.text);

                        await _model.saveData();

                        await _model.createRate();

                        croomTypeTextCntrl.clear();

                        camountTextCntrl.clear();
                        cdaysControler.clear();
                        clocationTextCntrl.clear();

                        setState(() {
                          _model.createRate();
                          _model.saveData();
                        });
                        showAlertDialog(context);
                      } else {
                        showAlerErrortDialog(context);
                      }
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 10, horizontal: 50),
                      child: Text("Confirm",
                          style: CommonStyles.whiteText18BoldW500()),
                    ),
                    style: ButtonStyle(
                        backgroundColor:
                        MaterialStateProperty.all(Colors.green),
                        shape:
                        MaterialStateProperty.all<RoundedRectangleBorder>(
                            RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12.0),
                                side: BorderSide(color: Colors.blue))))),
              ),
              SizedBox(
                height: 50,
              ),


              //////////////////////////////////////////////////////


              Image.asset("assets/images/aus.jpg"),

              SizedBox(
                height: 30,
              ),

              Text(
                "A hotel is a commercial establishment that provides lodging, meals, and other services to guests, travelers, and tourists. Hotels can range from small family-run businesses to large international chains. Most hotels list a variety of services, such as room service, laundry, and concierge. The hotel offers newspapers, conference rooms, and a restaurant on-site. It also has elegant, spacious bedrooms, each with comfortable seating areas, a television, air conditioning, a room safe, and a large desk, all designed for you to enjoy a perfect rest.",

                style: CommonStyles.black14(),
              )
            ],
          ),
        ),
      ),

    );
  }


  showAlertDialog(BuildContext context) {
    // set up the button
    Widget okButton = TextButton(
      child: Text(
        "OK",
        style: CommonStyles.green15(),
      ),
      onPressed: () {
        Navigator.pop(context);
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text(
        "Add Rating !!!",
        style: CommonStyles.black15(),
      ),
      content: Text(
        "Are you sure to Add Rating!!!...",
        style: CommonStyles.black13(),
      ),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  showAlerErrortDialog(BuildContext context) {
    // set up the button
    Widget okButton = TextButton(
      child: Text(
        "OK",
        style: CommonStyles.green15(),
      ),
      onPressed: () {
        Navigator.pop(context);
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text(
        "Add Ratings !!!",
        style: CommonStyles.black15(),
      ),
      content: Text(
        "Check your Enter Details !!!...",
        style: CommonStyles.black13(),
      ),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }
}