import 'package:flutter/material.dart';
import 'package:hotel_clg/common.dart';
import 'package:hotel_clg/login_screen.dart';
import 'package:hotel_clg/user/book_room_model.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {


  DataModelClass _model = DataModelClass();


  Future<void> _initData() async {
    await _model.createStudentData(); // Load data when initializing the state
    setState(() {}); // Trigger a rebuild to update the UI
  }
  @override
  void initState() {
    super.initState();
    _initData();
    setState(() {

    });
    // Load data when initializing the state
  }

  @override
  void dispose() {
    _model.saveData(); // Save data when the screen is disposed (e.g., navigating back)
    super.dispose();
  }




  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Booked Package',
          style: CommonStyles.blue18900(),
        ),
        automaticallyImplyLeading: false,
        centerTitle: true,
        backgroundColor: Colors.blue,
        actions: [
          IconButton(onPressed: (){
            setState(() {
              _model.createStudentData();
              _model.saveData();

            });
          }, icon: Icon(Icons.replay_circle_filled_rounded)),

          IconButton(
              onPressed: () {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (context) => LoginScreen()),
                      (route) => false, // Keep removing routes until this condition is met
                );
              },
              icon: Icon(
                Icons.login_outlined,
                color: Colors.white,
              )),
        ],
      ),
      body: Container(
        padding: EdgeInsets.all(20),
        child: _model.roomType.length != 0 ?
        ListView.builder(
          itemCount: _model.roomType.length,
          primary: false,
          shrinkWrap: true,
          itemBuilder: (context,index) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Card(
                child: Padding(
                  padding: EdgeInsets.all(15),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,

                              children: [
                                Text("Room Type",
                                style: CommonStyles.black13(),
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                Text(_model.roomType[index],
                                  style: CommonStyles.blue13900(),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 10,
                          ),

                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text("Date and Time",
                                  style: CommonStyles.black13(),
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                Text(_model.dateTime[index],
                                  style: CommonStyles.blue13900(),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 15,
                      ),

                      Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,

                              children: [
                                Text("Check In",
                                  style: CommonStyles.black13(),
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                Text(_model.checkIn[index],
                                  style: CommonStyles.blue13900(),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 10,
                          ),

                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text("Check Out",
                                  style: CommonStyles.black13(),
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                Text(_model.checkOut[index],
                                  style: CommonStyles.blue13900(),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 15,
                      ),

                      Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,

                              children: [
                                Text("Amount",
                                  style: CommonStyles.black13(),
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                Text(_model.amount[index],
                                  style: CommonStyles.blue13900(),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 10,
                          ),

                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text("No of Days",
                                  style: CommonStyles.black13(),
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                Text(_model.days[index],
                                  style: CommonStyles.blue13900(),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 15,
                      ),

                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Center(
                            child: ElevatedButton(
                                onPressed: () {},
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 10, horizontal: 10),
                                  child: Text("Confirm",
                                      style: CommonStyles
                                          .whiteText15BoldW500()),
                                ),
                                style: ButtonStyle(
                                    backgroundColor:
                                    MaterialStateProperty.all(
                                        Colors.green),
                                    shape: MaterialStateProperty.all<
                                        RoundedRectangleBorder>(
                                        RoundedRectangleBorder(
                                            borderRadius:
                                            BorderRadius.circular(
                                                12.0),
                                            side: BorderSide(
                                                color: Colors.blue))))),
                          ),
                          IconButton(onPressed: (){
                            setState(() {
                              _model.removeDataAtIndex(index);
                            });

                          }, icon: Icon(Icons.delete,
                          size: 28,
                            color: Colors.red,
                          ))
                        ],
                      ),

                    ],
                  ),
                ),
              ),

              SizedBox(
                height: 20,
              )
            ],
            );
          }
        ) : Center(
          child: Text("No Records Found !!!",
          style: CommonStyles.red15(),
          ),
        ),
      ),
    );
  }
}
