import 'package:shared_preferences/shared_preferences.dart';

class DataModelClass {
// Create Student

  List<String> roomType = [];
  List<String> location = [];
  List<String> dateTime = [];
  List<String> checkIn = [];

  List<String> checkOut = [];
  List<String> amount = [];
  List<String> days = [];

  Future<void> createStudentData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    roomType = prefs.getStringList('roomType') ?? [];
    location = prefs.getStringList('location') ?? [];
    dateTime = prefs.getStringList('dateTime') ?? [];
    checkIn = prefs.getStringList('checkIn') ?? [];
    days = prefs.getStringList('days') ?? [];
    checkOut = prefs.getStringList('checkOut') ?? [];
    amount = prefs.getStringList('amount') ?? [];
  }

  Future<void> saveData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setStringList('roomType', roomType);
    prefs.setStringList('location', location);
    prefs.setStringList('dateTime', dateTime);
    prefs.setStringList('checkIn', checkIn);
    prefs.setStringList('days', days);
    prefs.setStringList('checkOut', checkOut);
    prefs.setStringList('amount', amount);
  }

  // Remove data at a specific index
  void removeDataAtIndex(int index) {

      roomType.removeAt(index);
      location.removeAt(index);
      dateTime.removeAt(index);
      checkIn.removeAt(index);
      days.removeAt(index);
      checkOut.removeAt(index);
      amount.removeAt(index);

  }

}
