import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:hotel_clg/admin/rate_model.dart';
import 'package:hotel_clg/common.dart';



class RatingScreen extends StatefulWidget {
  const RatingScreen({super.key});

  @override
  State<RatingScreen> createState() => _RatingScreenState();
}

class _RatingScreenState extends State<RatingScreen> {
  CreateRateModel _model = CreateRateModel();

  List<String> image = [
    "assets/images/lxr.jpg",
    "assets/images/dr.jpg",
    "assets/images/dro.jpg",
    "assets/images/sr.jpg",
  ];



  Future<void> _initData() async {
    await _model.createRate(); // Load data when initializing the state
    setState(() {}); // Trigger a rebuild to update the UI
  }
  @override
  void initState() {
    super.initState();
    _initData();
    setState(() {

    });
    // Load data when initializing the state
  }

  @override
  void dispose() {
    _model.saveData(); // Save data when the screen is disposed (e.g., navigating back)
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Review and Rating',
          style: CommonStyles.blue18900(),
        ),
        automaticallyImplyLeading: true,
        centerTitle: true,
        backgroundColor: Colors.blue,
        actions: [
          IconButton(onPressed: (){
            setState(() {
              _model.createRate();
              _model.saveData();

            });
          }, icon: Icon(Icons.replay_circle_filled_rounded)),

        ],
      ),


      body: Container(
        padding: EdgeInsets.all(20),
        child: SingleChildScrollView(
          physics: BouncingScrollPhysics(),

          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ListView.builder(
                  itemCount: _model.rroomType.length,
                  primary: false,
                  shrinkWrap: true,
                  itemBuilder: (context,index) {
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Card(
                          child: Padding(
                            padding: EdgeInsets.all(15),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [

                                Container(
                                  height: 150,
                                  width: 280,
                                  child: Image.asset(
                                    _model.rroomType == 'Single Bed Room'
                                        ? image[2]
                                        : _model.rroomType ==
                                        'Double Bed Room'
                                        ? image[3]
                                        : _model.rroomType ==
                                        'Deluxe Rooms'
                                        ? image[1]
                                        : _model.rroomType ==
                                        'Luxury Rooms'
                                        ? image[0]
                                        : image[0],
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                SizedBox(
                                  height: 20,
                                ),

                                Row(
                                  children: [
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,

                                        children: [
                                          Text("Room Type",
                                            style: CommonStyles.black13(),
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Text(_model.rroomType[index],
                                            style: CommonStyles.blue13900(),
                                          ),
                                        ],
                                      ),
                                    ),
                                    SizedBox(
                                      width: 10,
                                    ),

                                  ],
                                ),
                                SizedBox(
                                  height: 15,
                                ),

                                Text("Location",
                                  style: CommonStyles.black13(),
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                Text(_model.rlocation[index],
                                  style: CommonStyles.blue13900(),
                                ),
                                SizedBox(
                                  height: 15,
                                ),

                                Text("FeedBack",
                                  style: CommonStyles.black13(),
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                Text(_model.rrate[index],
                                  style: CommonStyles.blue13900(),
                                ),

                                SizedBox(
                                  height: 15,
                                ),

                                Text("Rating",
                                  style: CommonStyles.black13(),
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                RatingBar.builder(
                                  initialRating: double.parse(_model.rdes[index]),
                                  minRating: 1,
                                  direction: Axis.horizontal,
                                  itemCount: 5,
                                  itemSize: 40,
                                  itemBuilder: (context, _) => Icon(
                                    Icons.star,
                                    color: Colors.orange,
                                  ),
                                  onRatingUpdate: (rating) {
                                    setState(() {

                                    });
                                  },
                                ),
                              ],
                            ),
                          ),
                        ),

                        SizedBox(
                          height: 20,
                        )
                      ],
                    );
                  }
              )
            ],
          ),
        ),
      ),
    );
  }
  double _rating = 0;

}
