import 'package:shared_preferences/shared_preferences.dart';

class CreateRateModel {
// Create Student

  List<String> rroomType = [];
  List<String> rlocation = [];
  List<String> rrate = [];
  List<String> rdes = [];

  Future<void> createRate() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    rroomType = prefs.getStringList('rroomType') ?? [];
    rlocation = prefs.getStringList('rlocation') ?? [];
    rrate = prefs.getStringList('rrate') ?? [];
    rdes = prefs.getStringList('rdes') ?? [];
  }

  Future<void> saveData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setStringList('rroomType', rroomType);
    prefs.setStringList('rlocation', rlocation);
    prefs.setStringList('rdes', rdes);
    prefs.setStringList('rrate', rrate);
  }

  // Remove data at a specific index
  void removeDataAtIndex(int index) {

    rroomType.removeAt(index);
    rlocation.removeAt(index);
    rdes.removeAt(index);
    rrate.removeAt(index);

  }

}
