import 'package:flutter/material.dart';
import 'package:hotel_clg/admin/create_room_model.dart';
import 'package:hotel_clg/common.dart';



class CreateRoomScree extends StatefulWidget {
  const CreateRoomScree({super.key});

  @override
  State<CreateRoomScree> createState() => _CreateRoomScreeState();
}

class _CreateRoomScreeState extends State<CreateRoomScree>{
  
  final TextEditingController croomTypeTextCntrl = TextEditingController();
  final TextEditingController clocationTextCntrl = TextEditingController();
  final TextEditingController camountTextCntrl = TextEditingController();
  final TextEditingController cdaysControler = TextEditingController();
  final TextEditingController cdesControler = TextEditingController();

  CreateRoomModel _model = CreateRoomModel();

  List<String> roomType = [
    'Single Bed Room',
    'Double Bed Room',
    'Deluxe Rooms',
    'Luxury Rooms',
  ];

  int selectRoom = 0;


  List<String> locationlist = [
    'Chennai',
    'Vellore',
    'ECR - Chennai',
    'Bangalore',
  ];

  int selectLoc = 0;
  

  Future<void> _initData() async {
    await _model.createRoom(); // Load data when initializing the state
    setState(() {}); // Trigger a rebuild to update the UI
  }

  @override
  void initState() {
    super.initState();
    _initData();
    setState(() {});
    // Load data when initializing the state
  }

  @override
  void dispose() {
    _model
        .saveData(); // Save data when the screen is disposed (e.g., navigating back)
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Add Rooms",
          style: CommonStyles.blue18900(),
        ),
        automaticallyImplyLeading: true,
        centerTitle: true,
        backgroundColor: Colors.blue,
      ),

      body: Container(
        padding: EdgeInsets.all(20),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              
              SizedBox(
                height: 20,
              ),
              Text(
                "Add Room Details :-",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                "Choose Room Type",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              ListView.builder(
                  itemCount: roomType.length,
                  shrinkWrap: true,
                  primary: false,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: GestureDetector(
                        onTap: () {
                          setState(() {
                            selectRoom = index;
                            croomTypeTextCntrl.text = roomType[index];
                          });
                        },
                        child: Card(
                          shape: selectRoom == index
                              ? RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                              side:
                              BorderSide(width: 1, color: Colors.blue))
                              : null,
                          child: Padding(
                            padding: EdgeInsets.symmetric(
                                vertical: 8, horizontal: 10),
                            child: Row(
                              children: [
                                IconButton(
                                    onPressed: () {},
                                    icon: Icon(
                                      Icons.hotel,
                                      color: Colors.blue,
                                    )),
                                SizedBox(
                                  width: 20,
                                ),
                                Text(
                                  roomType[index],
                                  style: selectRoom == index ? CommonStyles.blue13900() : CommonStyles.black13(),
                                )
                              ],
                            ),
                          ),
                        ),
                      ),
                    );
                  }),
              SizedBox(
                height: 20,
              ),
              Text(
                "Selected Room Type",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              TextFormField(
                readOnly: true,
                controller: croomTypeTextCntrl,
                style: CommonStyles.black13thin(),
                decoration: InputDecoration(
                  hintText: "Room Type",
                  labelStyle: CommonStyles.black13thin(),
                  hintStyle: CommonStyles.black13thin(),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(13)),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                "Choose Room Location",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              SizedBox(
                height: 80,
                child: ListView.builder(
                    itemCount: locationlist.length,
                    shrinkWrap: true,
                    scrollDirection: Axis.horizontal,
                    physics: BouncingScrollPhysics(),
                    primary: false,
                    itemBuilder: (context, index) {
                      return Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: GestureDetector(
                          onTap: () {
                            setState(() {
                              selectLoc = index;
                              clocationTextCntrl.text = locationlist[index];
                            });
                          },
                          child: Card(
                            shape: selectLoc == index
                                ? RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                                side:
                                BorderSide(width: 1, color: Colors.blue))
                                : null,
                            child: Padding(
                              padding: EdgeInsets.symmetric(
                                  vertical: 8, horizontal: 10),
                              child: Row(
                                children: [
                                  IconButton(
                                      onPressed: () {},
                                      icon: Icon(
                                        Icons.home_work_outlined,
                                        color: Colors.blue,
                                      )),
                                  SizedBox(
                                    width: 20,
                                  ),
                                  Text(
                                    locationlist[index],
                                    style: selectLoc == index ? CommonStyles.blue13900() : CommonStyles.black13(),
                                  )
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    }),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                "Location",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              TextFormField(
                readOnly: true,
                controller: clocationTextCntrl,
                style: CommonStyles.black13thin(),
                decoration: InputDecoration(
                  hintText: "Location",
                  labelStyle: CommonStyles.black13thin(),
                  hintStyle: CommonStyles.black13thin(),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(13)),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                "Amount",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              TextFormField(
                controller: camountTextCntrl,
                style: CommonStyles.black13thin(),
                decoration: InputDecoration(
                  hintText: "Amount",
                  labelStyle: CommonStyles.black13thin(),
                  hintStyle: CommonStyles.black13thin(),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(13)),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                "No of Days",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              TextFormField(
                controller: cdaysControler,
                style: CommonStyles.black13thin(),
                decoration: InputDecoration(
                  hintText: "No of Days",
                  labelStyle: CommonStyles.black13thin(),
                  hintStyle: CommonStyles.black13thin(),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(13)),
                ),
              ),

              SizedBox(
                height: 20,
              ),
              Text(
                "Description",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              TextFormField(
                controller: cdesControler,
                style: CommonStyles.black13thin(),
                decoration: InputDecoration(
                  hintText: "Description",
                  labelStyle: CommonStyles.black13thin(),
                  hintStyle: CommonStyles.black13thin(),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(13)),
                ),
              ),
              
              SizedBox(
                height: 30,
              ),
              Center(
                child: ElevatedButton(
                    onPressed: () async {
                      if (croomTypeTextCntrl.text != null &&
                          croomTypeTextCntrl.text.isNotEmpty &&
                          camountTextCntrl.text != null &&
                          camountTextCntrl.text.isNotEmpty &&
                          cdaysControler.text != null &&
                          cdaysControler.text.isNotEmpty &&
                          clocationTextCntrl.text != null &&
                          clocationTextCntrl.text.isNotEmpty &&
                          cdesControler.text != null &&
                          cdesControler.text.isNotEmpty
                      
                      ) {
                        _model.croomType.add(croomTypeTextCntrl.text);
                        _model.camount.add(camountTextCntrl.text);
                        _model.cdays.add(cdaysControler.text);
                        _model.clocation.add(clocationTextCntrl.text);
                        _model.cdes.add(cdesControler.text);

                        await _model.saveData();

                        await _model.createRoom();

                        croomTypeTextCntrl.clear();
                        cdesControler.clear();
                        camountTextCntrl.clear();
                        cdaysControler.clear();
                        clocationTextCntrl.clear();

                        setState(() {
                          _model.createRoom();
                          _model.saveData();
                        });
                        showAlertDialog(context);
                      } else {
                        showAlerErrortDialog(context);
                      }
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 10, horizontal: 50),
                      child: Text("Confirm",
                          style: CommonStyles.whiteText18BoldW500()),
                    ),
                    style: ButtonStyle(
                        backgroundColor:
                        MaterialStateProperty.all(Colors.green),
                        shape:
                        MaterialStateProperty.all<RoundedRectangleBorder>(
                            RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12.0),
                                side: BorderSide(color: Colors.blue))))),
              ),
              SizedBox(
                height: 50,
              ),
            ],
          ),
        ),
      ),
    );
  }

  showAlertDialog(BuildContext context) {
    // set up the button
    Widget okButton = TextButton(
      child: Text(
        "OK",
        style: CommonStyles.green15(),
      ),
      onPressed: () {
        Navigator.pop(context);
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text(
        "Add Room !!!",
        style: CommonStyles.black15(),
      ),
      content: Text(
        "Are you sure to Add Room!!!...",
        style: CommonStyles.black13(),
      ),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  showAlerErrortDialog(BuildContext context) {
    // set up the button
    Widget okButton = TextButton(
      child: Text(
        "OK",
        style: CommonStyles.green15(),
      ),
      onPressed: () {
        Navigator.pop(context);
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text(
        "Add Room !!!",
        style: CommonStyles.black15(),
      ),
      content: Text(
        "Check your Enter Details !!!...",
        style: CommonStyles.black13(),
      ),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }
}
