import 'package:flutter/material.dart';
import 'package:hotel_clg/common.dart';
import 'package:hotel_clg/user/message_model.dart';


class EnquireScreen extends StatefulWidget {
  const EnquireScreen({super.key});

  @override
  State<EnquireScreen> createState() => _EnquireScreenState();
}

class _EnquireScreenState extends State<EnquireScreen> {


  List<bool> status=[
  false,
    true,
    false,
    true,
    false
  ];

  MessageModel _model = MessageModel();


  Future<void> _initData() async {
    await _model.createStudentData(); // Load data when initializing the state
    setState(() {}); // Trigger a rebuild to update the UI
  }
  @override
  void initState() {
    super.initState();
    _initData();
    setState(() {

    });
    // Load data when initializing the state
  }

  @override
  void dispose() {
    _model.saveData(); // Save data when the screen is disposed (e.g., navigating back)
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Enquiries',
          style: CommonStyles.blue18900(),
        ),
        automaticallyImplyLeading: true,
        centerTitle: true,
        backgroundColor: Colors.blue,
        actions: [
          IconButton(onPressed: (){
            setState(() {
              _model.createStudentData();
              _model.saveData();

            });
          }, icon: Icon(Icons.replay_circle_filled_rounded)),

        ],
      ),


      body: Container(
        padding: EdgeInsets.all(20),
        child: SingleChildScrollView(
          physics: BouncingScrollPhysics(),

          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ListView.builder(
                  itemCount: _model.name.length,
                  primary: false,
                  shrinkWrap: true,
                  itemBuilder: (context,index) {
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Card(
                          child: Padding(
                            padding: EdgeInsets.all(15),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,

                                        children: [
                                          Text("Name",
                                            style: CommonStyles.black13(),
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Text(_model.name[index],
                                            style: CommonStyles.blue13900(),
                                          ),
                                        ],
                                      ),
                                    ),
                                    SizedBox(
                                      width: 10,
                                    ),

                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text("Status",
                                            style: CommonStyles.black13(),
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          ElevatedButton(
                                              onPressed: () {
                                                setState(() {
                                                  status[index] = !status[index];
                                                });
                                              },
                                              child: Padding(
                                                padding: const EdgeInsets.symmetric(
                                                    vertical: 10, horizontal: 10),
                                                child: Text(
                                                    status[index] == true ? "Confirm" : "Pending",
                                                    style: CommonStyles
                                                        .whiteText15BoldW500()),
                                              ),
                                              style: ButtonStyle(
                                                  backgroundColor:
                                                  MaterialStateProperty.all(
                                                      status[index] == true ? Colors.green : Colors.red),
                                                  shape: MaterialStateProperty.all<
                                                      RoundedRectangleBorder>(
                                                      RoundedRectangleBorder(
                                                          borderRadius:
                                                          BorderRadius.circular(
                                                              12.0),
                                                          side: BorderSide(
                                                              color: Colors.blue))))),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 15,
                                ),

                                Text("Form",
                                  style: CommonStyles.black13(),
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                Text(_model.name[index],
                                  style: CommonStyles.blue13900(),
                                ),
                                SizedBox(
                                  height: 15,
                                ),

                                Text("Subject",
                                  style: CommonStyles.black13(),
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                Text(_model.sub[index],
                                  style: CommonStyles.blue13900(),
                                ),

                                SizedBox(
                                  height: 15,
                                ),

                                Text("Message",
                                  style: CommonStyles.black13(),
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                Text(_model.message[index],
                                  style: CommonStyles.blue13900(),
                                ),

                              ],
                            ),
                          ),
                        ),

                        SizedBox(
                          height: 20,
                        )
                      ],
                    );
                  }
              )
            ],
          ),
        ),
      ),
    );
  }
}
